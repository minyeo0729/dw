let copyButton = document.getElementById('copyToClipboard');

// copyButton.addEventListener('click', () => {
//     let textCopy = document.getElementById('myDiv').innerText;
//     if(navigator.clipboard){
//         navigator.clipboard.writeText(textCopy).then(()=>{
//             alert('copied!')
//         })
//     }
// })

copyButton.addEventListener('click', () => {
    CopyText();
})
function SelectText(element) {
    var doc = document,
        range,
        selection;

    if (doc.body.createTextRange) {
        range = document.body.createTextRange();
        range.moveToElementText(element);
        range.select();
    } else if (window.getSelection) {
        selection = window.getSelection();
        range = document.createRange();
        range.selectNodeContents(element);
        selection.removeAllRanges();
        selection.addRange(range);
    }
}
function CopyText(){
    let textCopy = SelectText(this).innerText;
    if(navigator.clipboard){
        navigator.clipboard.writeText(textCopy).then(()=>{
            bootoast.toast({
                message: "<p><i class='fas fa-paste'></i>복사되었습니다!</p>",
                type: "info",
                position: "right-bottom",
                timeout: "2.5",
                animationDuration: "300",
                dismissable: false,
              });
        })
    }
}
// function CopyText(){
//     let textCopy = document.getElementById('myDiv').innerText;
//     if(navigator.clipboard){
//         navigator.clipboard.writeText(textCopy).then(()=>{
//             bootoast.toast({
//                 message: "<p><i class='fas fa-paste'></i>복사되었습니다!</p>",
//                 type: "info",
//                 position: "right-bottom",
//                 timeout: "2.5",
//                 animationDuration: "300",
//                 dismissable: false,
//               });
//         })
//     }
// }